﻿namespace DotFood.Entity
{
    public class UserHistory
    {

            public string UserId { get; internal set; }
            public string FullName { get; internal set; }
            public string Role { get; internal set; }
            public object Orders { get; internal set; }
        
    }   
}
