﻿namespace DotFood.ViewModel
{
    public class UserWithRolesViewModel
    {
        public DotFood.Entity.Users User { get; set; }
        public List<string> Roles { get; set; }
    }
}
