﻿namespace DotFood.ViewModel
{
    public class ManageUsersViewModel
    {
        public List<UserWithRolesViewModel> UsersWithRoles { get; set; }
    }
}
