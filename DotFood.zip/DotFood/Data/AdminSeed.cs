﻿namespace DotFood.Data
{
    public class AdminSeed
    {
    }
}
